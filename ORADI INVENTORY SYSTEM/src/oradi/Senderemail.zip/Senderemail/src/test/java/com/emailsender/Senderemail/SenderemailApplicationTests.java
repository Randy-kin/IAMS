package com.emailsender.Senderemail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenderemailApplicationTests {

	@Test
	void contextLoads() {
	}

}
