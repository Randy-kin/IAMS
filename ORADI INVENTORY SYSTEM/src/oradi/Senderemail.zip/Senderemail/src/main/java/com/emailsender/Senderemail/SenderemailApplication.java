package com.emailsender.Senderemail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenderemailApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenderemailApplication.class, args);
	}

}
